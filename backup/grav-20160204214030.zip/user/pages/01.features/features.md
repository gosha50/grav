---
title: Features
features:
    - title: Crazy Fast
      subtitle: So fast it will make your head spin
      icon: fighter-jet
    - title: Easily Extended
      subtitle: Built to be highly extensible
      icon: puzzle-piece
    - title: Fun to Use
      subtitle: Making web development work fun again
      icon: truck
---

slug: features
# Features List
