---
title: Config

access:
    admin.config: true
    admin.super: true
---
