---
title: Forgot password

form:
    fields:
        - name: username
          type: text
          placeholder: Username
          autofocus: true
---

